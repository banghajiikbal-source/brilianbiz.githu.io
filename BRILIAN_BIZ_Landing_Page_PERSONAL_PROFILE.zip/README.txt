BRILIAN.BIZ — LANDING PAGE MASTER
=================================

File index.html adalah prototype landing page siap preview dengan:
- Hero
- Profil
- Program
- Support System
- Presentasi
- FAQ
- CTA pendaftaran
- Footer

DUA LINK YANG PERLU DIGANTI:
1) Tombol "DAFTAR INFORMASI" / "DAFTAR SEKARANG" -> URL Google Form final.
2) Tombol "LIHAT PRESENTASI" -> URL video presentasi atau Google Meet.

CATATAN:
- Foto presenter dan logo memakai file yang diberikan pengguna.
- Untuk Google Sites, gunakan struktur dan teks yang sama, lalu upload foto/logo secara manual.
- Setelah Google Form selesai, ganti semua tombol CTA dengan link Form tersebut.
